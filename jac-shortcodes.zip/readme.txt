=== Handy WP Shortcodes ===
Contributors: Jacurtis
Tags: shortcode, highlight, highlighter, code, well, dark, syntax
Requires at least: 4.0
Tested up to: 4.6
Stable tag: master
License: MIT Open Source License
License URI: https://github.com/jacurtis/handy-wp-shortcodes

A simple set of useful shortcodes that do not rely on your theme. Switch themes and keep the shortcodes.